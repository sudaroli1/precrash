# Supplementary material

Everything needed to check the measurements in the paper. Nothing here contains
any part of the competition's dataset, and nothing here contains a label: the
competition publishes none, which is the premise of the whole study.

## submissions/

The twenty-seven submission files, exactly as uploaded to the competition's
scoring service, and the log of what each one scored.

Every file is a full-length prediction over all 1,417 clips of the private
split. Every one was generated from a closed-form expression in the frame
index alone. None reads a video frame, and none was derived from or informed
by any label.

  scores.csv        every submission with the private score the service
                    returned; this is the raw table behind Tables 4 to 8
  LOG.md            what each submission was for, in the order they were made,
                    with the arithmetic each one was designed to isolate

  p_*.csv           the probe family of Section 4.5. Step functions crossing
                    0.5 at a named frame, plus the two constants, the
                    never-crosses control and the two dip/drop curves that
                    isolate the stable-timing term.
  c_*.csv           logistic curves, submitted independently of the step
                    family and not used in the linear fit, as a check that
                    the fit is not an artefact of the step shape (Table 7).
  d_*.csv           the six one-frame diagnostics of Section 5.4. These are
                    the submissions that establish that the benchmark's
                    published formula does not reproduce its own scorer:
                    five curves that first exceed 0.5 at frame 75, identical
                    at frames 74 and 75, with no subsequent dip, spread 0.091
                    apart.
  0*_*.csv          the first five video-blind controls, in submission order.

## scripts/

The code that generated the submissions, recovered the decomposition, and drew
both figures.

  make_submission.py            writes any of the video-blind curves above
  make_diagnostics.py           writes the six one-frame diagnostics
  analyse_taa.py                the decomposition and the linear fit
  protocol_comparison.py        the corrected-protocol arithmetic of Section 7
  make_figure_pipeline.py       Figure 1
  make_figure_decomposition.py  Figure 2
  audit_agreement.py            consistency checks over scores.csv

The remaining scripts belong to the training-free ensemble that is the paper's
case study rather than its finding: feature extraction, inference and
evaluation. They are included so that the ninth-placed entry is reproducible,
not because any result in Sections 5 to 7 depends on them.

## figures/

Both figures as they appear in the paper, in PDF and PNG, from the scripts
above.

## What is not here

The competition's clips, features derived from them, and any label. The rules
prohibit redistributing the dataset, and no result reported in the paper needs
it: every measurement in Sections 5 and 6 is computed from submitted curves and
returned scores.

## Anonymity

Our team name is replaced by "our entry" throughout. The other twelve teams are
identified only as the competition's own public leaderboard identifies them.
